Insert into salers(name,email,password,address,phone)
values ('raheem','ra@gmail.com','123456','alex','5142162'),
('rio','rio@gmail.com','123456','indiana','90847192487'),
('raje','raje@gmail.com','123456','india','7756261'),
('morak','morak@gmail.com','123456','turkey','2341724');
