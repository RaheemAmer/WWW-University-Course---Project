Insert into product(salerid,name,price,quantity,descreption)
values ('1','delicate','303200','ten','Boutiques'),
('2','software','12500','eleven','Shoe'),
('3','hardware','40400','twelve','Arts'),
('4','electronics','19300','thirteen','Histories');