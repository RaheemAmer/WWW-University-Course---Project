Insert into users(name,email,password,address,phone)
values ('raheem','ra@gmail.com','30','egypt','51421262'),
('rio','ra@gmail.com','12','brazil','908472192487'),
('raje','ra@gmail.com','40','india','77562261'),
('morak','ra@gmail.com','19','turkey','23412724');