Insert into orders (userid,proid,name,total,quantity,descreption)
values ('1','1','raheem ordre','32','thirty','Boutique'),
('2','2','rio ordre','12','ten','Shoes'),
('3','3','raje ordre','40','hundred','Art'),
('4','4','morak ordre','19','three','History');