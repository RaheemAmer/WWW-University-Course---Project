﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;
using System.Data.SqlClient;

namespace WebApplicationR
{
    public partial class salerlogin : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }
        protected void IDlogin_Click(object sender, EventArgs e)
        {


            if (Page.IsValid == false)
            {
                return;

            }

            string connectionString = ConfigurationManager.ConnectionStrings["salesConnectionString"].ToString();
            SqlConnection conn = new SqlConnection(connectionString);
            string sql = " Select * From [salers] where email ='" + IDemail.Text.ToString() + "'";
            try
            {

                conn.Open();
                SqlCommand cmd = new SqlCommand(sql, conn);
                SqlDataReader dtreader = cmd.ExecuteReader();
                if (dtreader.Read())
                {
                    // e mail registred
                    // we check the password
                    if (IDpassword.Text.ToString() == dtreader["password"].ToString())
                    {
                        // loged
                        Session["email"] = dtreader["email"].ToString();
                        Session["salerid"] = dtreader["salerid"].ToString();
                        dtreader.Close();
                        conn.Close();
                        Response.Redirect("salermaster.aspx");

                    }
                    else
                    {
                        lbmesg.Text = " false password";
                        dtreader.Close();
                        conn.Close();
                        return;
                    }


                }
                else
                {
                    dtreader.Close();
                    conn.Close();
                    lbmesg.Text = " the Saler Id is not registred or false ";
                    return;

                }
            }
            catch (Exception ex)
            {
                lbmesg.Text = "Error in ExecuteReader " + ex.ToString();
            }
        }
    }
}