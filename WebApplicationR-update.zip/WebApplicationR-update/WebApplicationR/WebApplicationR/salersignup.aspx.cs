﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;
using System.Data.SqlClient;

namespace WebApplicationR
{
    public partial class salersignup : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }
        protected void IDsignup_Click(object sender, EventArgs e)
        {
            string sql;

            lbmesg.Text = "";

            if (Page.IsValid == false)
            {
                return;

            }
            string connectionString = ConfigurationManager.ConnectionStrings["salesConnectionString"].ToString();
            SqlConnection conn = new SqlConnection(connectionString);
            SqlCommand cmd1 = new SqlCommand();
            SqlDataReader dtreader;
            cmd1.Connection = conn;

            conn.Open();
            sql = " Select * From [salers] where email ='" + IDemail.Text.ToString() + "'";
            cmd1.CommandText = sql;
            dtreader = cmd1.ExecuteReader();

            if (dtreader.HasRows)
            {
                dtreader.Close();
                conn.Close();
                lbmesg.Text = " thes User is registed before";
                return;
            }
            dtreader.Close();

            // insert record
            sql = "INSERT INTO [dbo].[salers]([name],[email],[password],[address],[phone]) VALUES ('" + IDname.Text + "','" + IDemail.Text + "','" + IDpassword.Text + "','" + IDaddress.Text + "','" + IDphone.Text + "')";
            SqlCommand cmd = new SqlCommand(sql, conn);
            cmd.ExecuteNonQuery();
            conn.Close();
            Response.Redirect("salerlogin.aspx");

        }

    }
}