﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;
using System.Data.SqlClient;
using System.Data;

namespace WebApplicationR
{
    public partial class orderinsert : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["email"] == null || (Session["userid"] == null))
            {
                Response.Redirect("userlogin.aspx");
            }
        }
        protected void IDinsert_Click(object sender, EventArgs e)
        {

            string connectionString = ConfigurationManager.ConnectionStrings["salesConnectionString"].ToString();
            SqlConnection connection = new SqlConnection(connectionString);
            SqlCommand cmd = new SqlCommand("SPInserOrders", connection);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@userid", Session["userid"]);
            cmd.Parameters.AddWithValue("@proid", IDproid.Text.ToString());
            cmd.Parameters.AddWithValue("@name", IDname.Text.ToString());
            cmd.Parameters.AddWithValue("@total", IDtotal.Text.ToString());
            cmd.Parameters.AddWithValue("@quantity", IDquantity.Text.ToString());
            cmd.Parameters.AddWithValue("@descreption", IDdescreption.Text.ToString());

            try
            {
                connection.Open();
                cmd.ExecuteNonQuery();

                lbmessg.Text = "Order are inserted Successfully";
                connection.Close();
            }
            catch (Exception ex)
            {
                lbmessg.Text = "Error in execution " + ex.ToString();
            }

        }
    }
}