﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;
using System.Data.SqlClient;
using System.Data;

namespace WebApplicationR
{
    public partial class productdelete : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["email"] == null || (Session["salerid"] == null))
            {
                Response.Redirect("salerlogin.aspx");
            }
        }
        protected void IDdelete_Click(object sender, EventArgs e)
        {
            string connectionString = ConfigurationManager.ConnectionStrings["salesConnectionString"].ToString();
            SqlConnection connection = new SqlConnection(connectionString);
            SqlCommand cmd = new SqlCommand("SPDeleteProduct", connection);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@salerid", Session["salerid"]);
            cmd.Parameters.AddWithValue("@name", IDnmae.Text.ToString());
            try
            {
                connection.Open();
                cmd.ExecuteNonQuery();

                lbmesg.Text = "Product are deleted Successfully";
                connection.Close();
            }
            catch (Exception ex)
            {
                lbmesg.Text = "Error in execution " + ex.ToString();
            }

        }
    }
}