﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;
using System.Data.SqlClient;
using System.Data;

namespace WebApplicationR
{
    public partial class ajax : System.Web.UI.Page
    {
        SqlConnection conn;
        string sql = "";
        string connetionString = null;

        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["email"] == null || (Session["userid"] == null))
            {
                Response.Redirect("userlogin.aspx");
            }
            string connectionString = ConfigurationManager.ConnectionStrings["salesConnectionString"].ToString();
            SqlConnection conn = new SqlConnection(connectionString);
            Label2.Text = "Page loaded time : " + DateTime.Now.ToString();
        }
        protected void Button1_Click(object sender, EventArgs e)
        {
            loadCombo();
        }
        public void loadCombo()
        {
            string connectionString = ConfigurationManager.ConnectionStrings["salesConnectionString"].ToString();
            SqlConnection conn = new SqlConnection(connectionString);
            try
            {
                conn.Open();
                sql = "select userid,name from users";
                SqlDataAdapter adapter = new SqlDataAdapter();
                SqlCommand sqlCmd;
                DataSet ds = new DataSet();
                sqlCmd = new SqlCommand(sql, conn);
                adapter.SelectCommand = sqlCmd;
                adapter.Fill(ds);
                conn.Close();
                DropDownList1.DataTextField = "name";
                DropDownList1.DataValueField = "userid";
                DropDownList1.DataSource = ds.Tables[0];
                DropDownList1.DataBind();
            }
            catch (Exception ex)
            {
                Label1.Text = "Can not open connection ! " + ex.ToString();
            }
        }
        protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
        {
            string connectionString = ConfigurationManager.ConnectionStrings["salesConnectionString"].ToString();
            SqlConnection conn = new SqlConnection(connectionString);
            string pubid = DropDownList1.SelectedValue;
            sql = "select name,total,quantity,descreption from orders where  userid='" + pubid + "'";
            conn.Open();
            SqlDataAdapter adapter = new SqlDataAdapter();
            SqlCommand sqlCmd;
            DataSet ds = new DataSet();
            sqlCmd = new SqlCommand(sql, conn);
            adapter.SelectCommand = sqlCmd;
            adapter.Fill(ds);
            conn.Close();
            GridView1.DataSource = ds.Tables[0];
            GridView1.DataBind();

            Label1.Text = "Last updated time : " + DateTime.Now.ToString();
        }
     
    }
}