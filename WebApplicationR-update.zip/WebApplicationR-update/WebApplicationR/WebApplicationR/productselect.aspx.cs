﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;
using System.Data.SqlClient;
using System.Data;

namespace WebApplicationR
{
    public partial class productselect : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["email"] == null || (Session["salerid"] == null))
            {
                Response.Redirect("salerlogin.aspx");
            }

        }
        protected void IDselect_Click(object sender, EventArgs e)
        {
            string connectionString = ConfigurationManager.ConnectionStrings["salesConnectionString"].ToString();
            SqlConnection connection = new SqlConnection(connectionString);
            SqlCommand cmd = new SqlCommand("product", connection);
            SqlDataAdapter adapter = new SqlDataAdapter("SPSelectProduct", connection);
            DataSet ds = new DataSet();
            SqlParameter param;

            try
            {
                connection.Open();
                cmd.Connection = connection;
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "SPSelectProduct";
                param = new SqlParameter("price", IDprice.Text.ToString());
                param.Direction = ParameterDirection.Input;
                param.DbType = DbType.String;
                cmd.Parameters.Add(param);

                adapter = new SqlDataAdapter(cmd);
                adapter.Fill(ds);
                connection.Close();
                ListBox1.DataSource = ds.Tables[0];
                ListBox1.DataTextField = "name";
                ListBox1.DataBind();

            }
            catch (Exception ex)
            {
                lbmessg.Text = "Error in execution " + ex.ToString();
            }

        }

    }
}